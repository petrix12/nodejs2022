# Notas:
Este es mi primer programa en Node

```
Options:
      --help     Show help                                             [boolean]
      --version  Show version number                                   [boolean]
  -b, --base     Es la base de la tabla de multiplicar       [number] [required]
  -h, --hasta    Este es el número hasta donde quieres la tabla
                                                          [number] [default: 10]
  -l, --listar   Muestra la tabla en consola          [boolean] [default: false]
```