# Información
Esta carpeta contiene el producto final de la aplicación